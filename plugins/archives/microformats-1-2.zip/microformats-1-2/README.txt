Microformats 1.2
================

Hello. Thank you for downloading the Microformats plug-in for Coda 2.

This plugin allows you to create hCard, hCalendar and now hReview micro formats using a simple set of forms.

Fill out the fields and you will get HTML markup with the appropriate CSS classes for the micro format you choose.

The HTML is meant as a starting point for you to customize as you see fit, however, if the HTML serves your needs, please feel free to use it.


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


Changelog
=========

Version 1.2

* Added hReviews

Version 1.1.2

* Now compiled to run on Mac OS X 10.6

Version 1.1.1

* Fixed the order in which tabbing through the fields works on the Card tab

Version 1.1

* The "Insert Microformat…" option is now only enabled in the code editor view

Version 1.0

* Initial release