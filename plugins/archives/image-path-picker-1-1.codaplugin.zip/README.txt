Image Path Picker 1.1
=====================

Hello. Thank you for downloading the Image Path Picker plug-in for Coda 2.

This plugin allows you to get the path for any image you choose from the dialog box.

By default, the dialog box will open to whatever directory your local site directory is set to (if set).

This plug-in only allows you select image files and only one at a time.

The path options will change dynamically based on your site settings. Filling out the local and remote path, and local and remote URL will make those options available. The absolute path is always available.

The quote options are self-explanatory.

--------------------------------------

Version 1.1

* The "Insert Image Path…" option is now only enabled in the code editor view