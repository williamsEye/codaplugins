HTML Entities 1.1.1
===================

Hello. Thank you for downloading the HTML Entities plug-in for Coda 2.

Coda 2 features an option under the Text > Processing menu to encode entities.

In addition you can find the Special Characters palette under the Edit menu or by pressing Option-Command-T.

This plug-in uses these two features to automatically encode any special characters into an HTML entity.

To use it you can do the following:

1. Press Option-Command-T
2. Double-click on a special character that you wish to encode
3. There is no step 3!

Whatever characters that Coda's "Encode Entities" menu item encodes will get encoded directly in your editor.

This functionality is ONLY available for HTML and XML documents.

The Special Characters palette functions as it normally does for all other document formats.

This plug-in is extremely alpha and as such has some quirks: 

- When using undo on an encoded character you will see the raw special character in its place. You will have to undo again to get back to the state before you entered the raw character. I am looking into this.

- The speed of your editor MAY be impacted. I have not noticed a slowdown, but my testing has been brief thus far.


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


Changelog
=========

Version 1.1.1

* Fixed a potential crashing bug - yes, this is still alpha!

Version 1.1

* Fixed a bug where plug-in would encode characters for non-HTML/XML documents

Version 1.0

* Initial release