Image Path Picker 1.1.1
=======================

Hello. Thank you for downloading the Image Path Picker plug-in for Coda 2.

This plugin allows you to get the path for any image you choose from the dialog box.

By default, the dialog box will open to whatever directory your local site directory is set to (if set).

This plug-in only allows you select image files and only one at a time.

The path options will change dynamically based on your site settings. Filling out the local and remote path, and local and remote URL will make those options available. The absolute path is always available.

The quote options are self-explanatory.


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


Changelog
=========

Version 1.1.1

* Now compiled to run on Mac OS X 10.6

Version 1.1

* The "Insert Image Path…" option is now only enabled in the code editor view

Version 1.0

* Initial release