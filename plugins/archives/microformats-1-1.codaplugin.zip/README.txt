Microformats 1.1
=====================

Hello. Thank you for downloading the Microformats plug-in for Coda 2.

This plugin allows you to create hCard and hCalendar micro formats using a simple set of forms.

Fill out the fields and you will get HTML markup with the appropriate CSS classes for the micro format you choose.

The HTML is meant as a starting point for you to customize as you see fit, however, if the HTML serves your needs, please feel free to use it.

--------------------------------------

Version 1.1

* The "Insert Microformat…" option is now only enabled in the code editor view