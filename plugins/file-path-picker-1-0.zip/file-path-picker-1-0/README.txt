File Path Picker 1.0
====================

Hello. Thank you for downloading the File Path Picker plug-in for Coda 2.

This plugin allows you to get the path for any file you choose from the dialog box.

By default, the dialog box will open to whatever directory your local site directory is set to (if set).

The path options will change dynamically based on your site settings. Filling out the local and remote path, and local and remote URL will make those options available. The absolute path is always available.

The quote options are self-explanatory.

You can use this plug-in via the Plug-ins menu item in Coda 2 or by pressing Control-Option-Command-F on your keyboard.


Installation
============

For best result, please do the following:

1. Close Coda 2
2. Open Coda 2
3. Double-click not the "File Path Picker.codaplugin" file

You should find the "Insert File Path…" option under the Plug-ins menu item in Coda 2.


Uninstallation
==============

For best result, please do the following:

1. Close Coda 2
2. In Finder, navigate to: /Users/YOUR USER DIRECTORY/Library/Application Support/Coda 2/Plug-ins/
3. Select the "File Path Picker.codaplugin" file and move it to the Trash
4. Open Coda 2


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


License
=======

File Path Picker is distributed under The MIT License (MIT). Please refer to 'LICENSE' file for more information.


Changelog
=========

Version 1.0

* Initial release